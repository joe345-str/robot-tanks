# ROBOT-TANKS — Build 0.2
**Mad Purple Hat Games** · Destruction • Upgrade • Survive • Repeat

This is the sprite-integrated local browser prototype. It includes five selectable tank classes, enemy hordes, shooting, enemy projectiles, destructible and secret walls, loot, hull repair, upgrades, combo scoring, boss waves, explosion animations, on-screen announcer callouts, and touch controls.

## Run it

From this folder, run:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080` on the same device. If port 8080 is already in use, choose another port, such as `8081`, and open that port instead. A local web server is recommended for testing.

## Controls
- **Move:** WASD or arrow keys; mobile D-pad
- **Aim:** mouse or touch the arena
- **Fire:** mouse click, Space, or FIRE button
- **Special:** E or SPECIAL button
- **Redeploy after defeat:** R or REDEPLOY

## Tank classes
- **Mechanioid:** heavy siege cannon and radial siege blast
- **Android:** fast adaptive burst fire and radial burst
- **Drone:** fast, fragile carpet-bomb specialist
- **Mammoth Terminator:** slow, heavily armored ground shaker
- **Cyborg:** regeneration special

## Sprite integration
Build 0.2 uses the files in `assets/sprites/sheets/`: all five tank sprites, enemy sprites, boss sprites, projectile sprites, pickup sprites, and explosion effects. The sprite loader is `assets/sprites/sheets/sprites.js`; `atlas.js` contains the atlas data. Individual transparent PNGs are under `assets/sprites/sheets/individual/`. If sprites fail to load, the game has canvas-drawn fallback actors.

The sprite art is sliced from the provided art-direction poster. Character sprites use single poses rather than full hand-drawn movement cycles; explosion animations are derived animation strips.

## Important status
This remains a **local single-player prototype**. Online multiplayer, persistent accounts/saves, server-authoritative gameplay, storefront integration, and real-money purchases are **not implemented**. Music and recorded announcer voices are not included; announcer callouts currently appear as on-screen text. Do not advertise these features as live until they have been built and tested.
