/* Robot-Tanks sprite helper — loads atlas.json + the sheet images and draws frames / animations on a canvas.
   const S = await RobotSprites.load('assets/sprites/sheets/');
   S.draw(ctx,'tanks','mechanioid',x,y,{scale:.6,angle:0,flip:false,flash:false,alpha:1});
   S.drawAnim(ctx,'small_explosion_anim',x,y,startTimeMs,nowMs,{scale:1});   // returns false when a non-looping anim has finished
   S.names('enemies') -> ['zombie',...]   S.animNames() -> ['small_explosion_anim',...]                                 */
(function (root) {
  'use strict';
  function loadImage(src) { return new Promise(function (res, rej) { var i = new Image(); i.onload = function () { res(i); }; i.onerror = function () { rej(new Error('Could not load ' + src)); }; i.src = src; }); }
  async function load(base) {
    base = base || ''; var atlas = window.ROBOT_ATLAS || await (await fetch(base + 'atlas.json')).json(), images = {}, flash = {};
    await Promise.all(Object.entries(atlas.sheets).map(async function (kv) {
      images[kv[0]] = await loadImage(base + kv[1].image);
      if (kv[1].flash_image) flash[kv[0]] = await loadImage(base + kv[1].flash_image);
    }));
    function frame(sheet, name) { var s = atlas.sheets[sheet]; var f = s && s.frames[name]; if (!f) throw new Error('No sprite ' + sheet + '/' + name); return [s, f]; }
    function draw(ctx, sheet, name, x, y, o) {
      o = o || {}; var sf = frame(sheet, name), f = sf[1], img = (o.flash && flash[sheet]) || images[sheet], sc = o.scale == null ? 1 : o.scale;
      ctx.save(); ctx.translate(x, y); if (o.angle) ctx.rotate(o.angle); if (o.flip) ctx.scale(-1, 1); if (o.alpha != null) ctx.globalAlpha = o.alpha;
      ctx.drawImage(img, f.x, f.y, f.w, f.h, -f.w * f.pivot[0] * sc, -f.h * f.pivot[1] * sc, f.w * sc, f.h * sc); ctx.restore();
    }
    function animFrame(anim, start, now) {
      var a = atlas.animations[anim]; if (!a) throw new Error('No animation ' + anim);
      var i = Math.floor((now - start) / 1000 * a.fps); if (a.loop) i %= a.frames.length; else if (i >= a.frames.length) return null; return a.frames[Math.max(0, i)];
    }
    function drawAnim(ctx, anim, x, y, start, now, o) { var n = animFrame(anim, start, now); if (!n) return false; draw(ctx, atlas.animations[anim].sheet, n, x, y, o); return true; }
    return { atlas: atlas, images: images, draw: draw, animFrame: animFrame, drawAnim: drawAnim,
      names: function (sheet) { return Object.keys(atlas.sheets[sheet].frames); }, animNames: function () { return Object.keys(atlas.animations); } };
  }
  root.RobotSprites = { load: load };
})(window);
