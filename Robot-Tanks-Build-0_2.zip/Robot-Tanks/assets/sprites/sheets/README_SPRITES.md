# Robot-Tanks — sprite sheets (Build 0.2)

Sliced from the Mad Purple Hat Games art-direction poster: **73 transparent sprites + 11 derived animation strips**.
Open `sprite-viewer.html` (serve the folder, e.g. `python -m http.server`) to browse everything, flip background / zoom / hit-flash,
and click a sprite to copy its name. `preview.png` is the whole set at a glance.

| Sheet | Sprites | Notes |
|---|---|---|
| tanks.png | mechanioid, android, drone, mammoth_terminator, cyborg | + `tanks_flash.png` |
| enemies.png | zombie, killer_clown, mutant, reptilian, vampire, werewolf, spider, skull_bot, turret | + `enemies_flash.png` |
| bosses.png | mutant_behemoth, cyborg_colossus, mammoth_war_machine, underground_worm | + `bosses_flash.png` |
| tiles.png | city_ruins, factory, desert, space_station, ice_world, lava, forest, dungeon, alien, secret_room | isometric arena tiles |
| projectiles.png | shell, rocket, laser, plasma, torpedo, missile, flame, chain_gun, railgun, mortar, emp, mine | |
| pickups.png | health, armor, ammo, coins, damage_up, speed_boost, shield, extra_life, upgrade, nuke, key, mystery | |
| effects.png | small/medium/large_explosion, chain_reaction, wall_destruction, wall_burning, fire, poison, electric, snow_ice, lava_burst | glow effects have true alpha (look right on any floor) |
| hazards.png | mines, electric_floor, lava_pool, toxic_pool, falling_rocks, turrets, ice, explosive_barrels | |
| fx_anim.png | 11 animation strips (89 frames) | explosions, fire, flame, poison, electric, laser, lava burst, snow/ice |
| ui.png | logo, loot_room | opaque art (not cut out) |

Every sprite is also saved on its own in `individual/<sheet>/<name>.png`. `atlas.json` lists each frame's cell rectangle, `pivot`
(normalised, feet-anchored for characters) and `trim` rectangle, plus the animations (frames, fps, loop).

> `atlas.js` is the same data as `atlas.json` as a script, so the sprites also load when the page is opened from disk (no web server needed).

## Use in the game
```html
<script src="assets/sprites/sheets/atlas.js"></script>
<script src="assets/sprites/sheets/sprites.js"></script>
<script>
const S = await RobotSprites.load('assets/sprites/sheets/');
S.draw(ctx, 'tanks', 'mechanioid', x, y, {scale: .6, flip: facingLeft, flash: justHit});   // flash = white hit silhouette
S.draw(ctx, 'projectiles', 'rocket', bx, by, {angle: Math.atan2(vy, vx)});
if (!S.drawAnim(ctx, 'large_explosion_anim', ex, ey, startMs, performance.now(), {scale: 1.2})) removeExplosion();
</script>
```

## Honest limits
* **Resolution:** the poster is 1312x1199, so sprites are small (about 45-170 px). They look right at 0.5x-1.5x; beyond that they soften.
  For crisp production art, re-run the tools on a higher-resolution poster (see `tools/README.txt`).
* **One pose each.** There are no walk cycles or attack frames: characters are single poses (use bob/flip/flash in code for life).
  Tanks are drawn in a 3/4 view, so flip left/right for facing rather than rotating them like a top-down sprite.
* **Animations are derived** from the poster stills (scale / fade / flicker), not hand-drawn.
* Slicing was automatic and checked by eye; edges are clean but a few sprites may have a stray pixel or soft shadow.
