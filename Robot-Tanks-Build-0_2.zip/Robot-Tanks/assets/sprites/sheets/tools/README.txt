Re-slice / rebuild everything:
  pip install pillow numpy scipy
  python tools/make_sheets.py
(reads tools/poster.png, rewrites every sheet, atlas.json and individual/ in the parent folder.
To use a higher-resolution poster, replace tools/poster.png and adjust the boxes in tools/slices.py ROWS.)
