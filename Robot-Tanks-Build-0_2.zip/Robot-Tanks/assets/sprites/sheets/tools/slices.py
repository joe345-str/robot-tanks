"""Master slice table for the Robot-Tanks poster: every sprite's name + bounding box (poster pixels)."""
import numpy as np, json
from PIL import Image
import os
HERE=os.path.dirname(os.path.abspath(__file__))
im=np.array(Image.open(os.path.join(HERE,'poster.png')).convert('RGB')).astype(int)
HEADERS=[(394,4,556,31),(6,290,94,315),(796,290,884,315),(1026,482,1216,506),(4,764,200,787),(4,482,262,501),(606,482,764,501)]
for (a,b,c,d) in HEADERS:
    reg=im[max(0,b-6):b-2,a:c]; im[b:d,a:c]=np.median(reg.reshape(-1,3),axis=0) if reg.size else im[b:d,a:c]
def _bg(sub):
    pts=np.concatenate([sub[0:3].reshape(-1,3),sub[-3:].reshape(-1,3),sub[:,0:3].reshape(-1,3),sub[:,-3:].reshape(-1,3)]); return np.median(pts,axis=0)
def split(box,thr=40,mingap=2,minw=14,mintall=18):
    x0,y0,x1,y1=box; sub=im[y0:y1,x0:x1]; m=np.abs(sub-_bg(sub)).max(axis=2)>thr
    col=m.sum(axis=0)>2; segs=[];start=None;gap=0
    for x,v in enumerate(col):
        if v:
            if start is None: start=x
            gap=0
        elif start is not None:
            gap+=1
            if gap>=mingap: segs.append((start,x-gap+1)); start=None; gap=0
    if start is not None: segs.append((start,len(col)))
    out=[]
    for a,b in segs:
        ys=np.where(m[:,a:b].sum(axis=1)>1)[0]
        if len(ys)==0 or b-a<minw or (ys.max()-ys.min())<mintall: continue
        out.append((int(x0+a),int(y0+ys.min()),int(x0+b),int(y0+ys.max()+1)))
    return out
# (category, [names], region box, gap)
ROWS=[
 ('tanks',     ['mechanioid','android','drone','mammoth_terminator','cyborg'],                                   (388,24,1312,166),3),
 ('enemies',   ['zombie','killer_clown','mutant','reptilian','vampire','werewolf','spider','skull_bot','turret'], (4,296,790,442),1),
 ('bosses',    ['mutant_behemoth','cyborg_colossus','mammoth_war_machine','underground_worm'],                   (798,296,1312,442),3),
 ('tiles',     ['city_ruins','factory','desert','space_station','ice_world'],                                    (4,500,600,602),3),
 ('tiles',     ['lava','forest','dungeon','alien','secret_room'],                                                (4,622,600,727),3),
 ('projectiles',['shell','rocket','laser','plasma','torpedo','missile'],                                         (606,505,1020,605),3),
 ('projectiles',['flame','chain_gun','railgun','mortar','emp','mine'],                                           (606,640,1020,730),3),
 ('pickups',   ['health','armor','ammo','coins'],                                                                (1025,500,1312,560),3),
 ('pickups',   ['damage_up','speed_boost','shield','extra_life'],                                                (1025,588,1312,640),3),
 ('pickups',   ['upgrade','nuke','key','mystery'],                                                               (1025,668,1312,730),3),
 ('effects',   ['small_explosion','medium_explosion','large_explosion','chain_reaction','wall_destruction'],      (4,788,590,893),3),
 ('effects',   ['wall_burning','fire','poison','electric','snow_ice','lava_burst'],                              (4,912,590,975),3),
 ('hazards',   ['mines','electric_floor','lava_pool','toxic_pool'],                                              (800,798,1108,858),3),
 ('hazards',   ['falling_rocks','turrets','ice','explosive_barrels'],                                            (800,886,1108,954),3),
]
def build():
    out={}
    for cat,names,box,gap in ROWS:
        bx=split(box,mingap=gap)
        if len(bx)!=len(names): raise SystemExit(f'{cat} {names[0]}..: found {len(bx)} boxes, want {len(names)}: {[(b[0],b[2]-b[0]) for b in bx]}')
        for n,b in zip(names,bx): out.setdefault(cat,[]).append((n,b))
    return out
if __name__=='__main__':
    from PIL import ImageDraw
    t=build(); dbg=Image.open(os.path.join(HERE,'poster.png')).convert('RGB'); d=ImageDraw.Draw(dbg)
    for cat,items in t.items():
        for n,b in items: d.rectangle(b,outline=(0,255,0),width=1)
    dbg.save(os.path.join(HERE,'slices_debug.png')); print({k:len(v) for k,v in t.items()}, sum(len(v) for v in t.values()),'sprites')
    json.dump({k:[(n,list(b)) for n,b in v] for k,v in t.items()},open(os.path.join(HERE,'slices.json'),'w'),indent=1)
