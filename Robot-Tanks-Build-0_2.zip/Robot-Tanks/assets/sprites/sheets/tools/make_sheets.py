"""Slice the Robot-Tanks concept poster into transparent sprites, pack sprite sheets + atlas.json,
build derived animation strips (explosions, fire, electric...) and white hit-flash sheets."""
import numpy as np, json, os, math, random
from PIL import Image, ImageDraw, ImageFilter
from scipy import ndimage as ndi
import sys
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import slices
OUT=os.path.abspath(os.path.join(HERE,'..'))
IND=OUT+'/individual'
os.makedirs(IND,exist_ok=True)
poster=Image.open(os.path.join(HERE,'poster.png')).convert('RGB'); P=np.array(poster).astype(np.float32)
# ───────── which items are light/glow effects (alpha from brightness) vs solid objects (flood-fill background removal)
GLOW={'small_explosion','medium_explosion','large_explosion','chain_reaction','fire','poison','electric','lava_burst','flame','laser','damage_up'}
PIVOT={'tanks':(.5,.55),'enemies':(.5,.88),'bosses':(.5,.88),'tiles':(.5,.5),'projectiles':(.5,.5),'pickups':(.5,.5),'effects':(.5,.5),'hazards':(.5,.6)}
COLS={'tanks':5,'enemies':5,'bosses':4,'tiles':5,'projectiles':6,'pickups':4,'effects':6,'hazards':4}

def drop_labels(a):
    # remove caption text that sits just BELOW the sprite: small detached pieces whose top is at/below the body's bottom edge
    mm=a>.25
    if not mm.any(): return a
    l9,n9=ndi.label(ndi.binary_dilation(mm,np.ones((9,9),bool)))
    sizes=ndi.sum(mm,l9,range(1,n9+1)); main=int(np.argmax(sizes))+1
    ys=np.where((l9==main)&mm)[0]; bottom=ys.max()
    l3,n3=ndi.label(ndi.binary_dilation(mm,np.ones((3,3),bool)))
    for i,sl in enumerate(ndi.find_objects(l3),1):
        top,bot=sl[0].start,sl[0].stop
        if top>=bottom-2 and (bot-top)<=15 and not (l9[sl][l3[sl]==i]==main).any(): a[(l3==i)]=0
        elif top>=bottom+2 and (bot-top)<=15: a[(l3==i)]=0
    return a

def cutout(name,box,pad=3):
    x0,y0,x1,y1=box; x0-=pad;y0-=pad;x1+=pad;y1+=pad
    sub=P[y0:y1,x0:x1].copy(); h,w,_=sub.shape
    ring=np.concatenate([sub[0],sub[-1],sub[:,0],sub[:,-1]]); bg=np.median(ring,axis=0)
    if name in GLOW:
        # additive-light sprite: brightness above the background = opacity, colour un-mixed from the background
        diff=np.clip(sub-bg,0,None).max(axis=2)
        a=np.clip((diff-9)/105.0,0,1)**0.9
        a=drop_labels(ndi.gaussian_filter(a,.5))
        rgb=np.clip((sub-bg*(1-a[...,None]))/np.maximum(a[...,None],.06),0,255)
        out=np.dstack([rgb,a*255])
    else:
        # solid sprite: background = flat, bg-coloured pixels reachable from the border. Using "flat" (low gradient) as well as "dark"
        # means a sprite's own near-black shading is kept, because it is enclosed by outlines/detail the flood cannot cross.
        d=np.abs(sub-bg).max(axis=2)
        lum=ndi.gaussian_filter(sub@np.array([.299,.587,.114],np.float32),.8)
        g=np.hypot(ndi.sobel(lum,0),ndi.sobel(lum,1))/8
        cand=(d<34)&(g<5.0)
        lab,n=ndi.label(cand)
        edge=set(np.unique(np.concatenate([lab[0],lab[-1],lab[:,0],lab[:,-1]])))-{0}
        a=(~np.isin(lab,list(edge))).astype(np.float32)
        # drop specks and detached label-text fragments (parts that are tiny next to the main body)
        mm=a>.5; l2,n2=ndi.label(ndi.binary_dilation(mm,np.ones((7,7),bool)))
        if n2>1:
            sizes=ndi.sum(mm,l2,range(1,n2+1)); big=sizes.max(); keep=[i+1 for i,sz in enumerate(sizes) if sz>=max(40,.12*big)]
            a=(mm&np.isin(l2,keep)).astype(np.float32)
        a=ndi.binary_fill_holes(drop_labels(a)>.5).astype(np.float32)
        a=ndi.gaussian_filter(a,.6); a=np.clip((a-.1)/.8,0,1)
        out=np.dstack([sub,a*255])
    im=Image.fromarray(out.astype(np.uint8),'RGBA')
    bb=im.getchannel('A').point(lambda v:255 if v>14 else 0).getbbox()
    return im.crop(bb) if bb else im

def silhouette(im,col=(255,255,255)):
    a=im.getchannel('A'); w=Image.new('RGBA',im.size,col+(0,)); w.putalpha(a); return w

def pack(frames,cols,pad=3):
    cw=max(f.width for f in frames)+pad*2; ch=max(f.height for f in frames)+pad*2
    rows=math.ceil(len(frames)/cols); sheet=Image.new('RGBA',(cw*cols,ch*rows),(0,0,0,0)); pos=[]
    for i,f in enumerate(frames):
        cx,cy=(i%cols)*cw,(i//cols)*ch; ox=cx+(cw-f.width)//2; oy=cy+(ch-f.height)//2
        sheet.alpha_composite(f,(ox,oy)); pos.append((cx,cy,cw,ch,ox-cx,oy-cy,f.width,f.height))
    return sheet,(cw,ch),pos

def main():
    table=slices.build(); atlas={'meta':{'game':'Robot-Tanks','source':'robot-tanks-art-direction poster (sliced)','note':'frames are cells; pivot is normalised within the cell; trim = sprite rectangle inside the cell'},'sheets':{},'animations':{}}
    sprites={}
    for cat,items in table.items():
        frames=[];names=[]
        for n,b in items:
            im=cutout(n,b); sprites[n]=(cat,im); frames.append(im); names.append(n)
            os.makedirs(f'{IND}/{cat}',exist_ok=True); im.save(f'{IND}/{cat}/{n}.png')
        sheet,cell,pos=pack(frames,COLS[cat]); sheet.save(f'{OUT}/{cat}.png',optimize=True)
        fr={n:{'x':p[0],'y':p[1],'w':p[2],'h':p[3],'pivot':list(PIVOT[cat]),'trim':{'x':p[4],'y':p[5],'w':p[6],'h':p[7]}} for n,p in zip(names,pos)}
        atlas['sheets'][cat]={'image':f'{cat}.png','cell':list(cell),'size':list(sheet.size),'frames':fr}
        if cat in('tanks','enemies','bosses'):                                  # white hit-flash twin with identical layout
            fl=Image.new('RGBA',sheet.size,(0,0,0,0))
            for f,p in zip(frames,pos): fl.alpha_composite(silhouette(f),(p[0]+p[4],p[1]+p[5]))
            fl.save(f'{OUT}/{cat}_flash.png',optimize=True); atlas['sheets'][cat]['flash_image']=f'{cat}_flash.png'
    # ───── derived animation strips (procedural: scale / fade / flicker of the poster stills) ─────
    def scaled(im,s,sy=None):
        sy=sy or s; return im.resize((max(1,int(im.width*s)),max(1,int(im.height*sy))),Image.LANCZOS)
    def fade(im,k):
        r,g,b,a=im.split(); a=a.point(lambda v:int(v*max(0,min(1,k)))); return Image.merge('RGBA',(r,g,b,a))
    def bright(im,k):
        r,g,b,a=im.split(); f=lambda v:int(min(255,v*k)); return Image.merge('RGBA',(r.point(f),g.point(f),b.point(f),a))
    anims={}; rnd=random.Random(7)
    def explode(name,n,s0,s1,fps,loop=False):
        base=sprites[name][1]; fr=[]
        for i in range(n):
            t=i/n; e=1-(1-t)**2.2; s=s0+(s1-s0)*e
            a=min(1,(t+.1)/.28) if t<.18 else max(0,1-((t-.18)/.82)**1.7)
            im=scaled(base,s); im=bright(im,1.35-.35*t) if t<.5 else im; fr.append(fade(im,a))
        anims[f'{name}_anim']=(fr,fps,loop,name)
    for nm,n,s0,s1 in [('small_explosion',8,.4,1.15),('medium_explosion',9,.4,1.15),('large_explosion',10,.35,1.15),('chain_reaction',10,.35,1.12)]: explode(nm,n,s0,s1,24)
    explode('lava_burst',8,.45,1.1,20); explode('snow_ice',8,.5,1.08,20)
    def flicker(name,n,fps,kind):
        base=sprites[name][1]; fr=[]
        for i in range(n):
            ph=2*math.pi*i/n
            if kind=='fire': im=scaled(base,1+.04*math.sin(ph),1+.09*math.sin(ph*2+1)); im=bright(im,1+.12*math.sin(ph*3))
            elif kind=='pulse': im=scaled(base,1+.07*math.sin(ph)); im=fade(im,.82+.18*math.sin(ph+1))
            elif kind=='flick_noflip': im=bright(scaled(base,.97+.06*rnd.random()),.8+.5*rnd.random())
            else:
                im=base.transpose(Image.FLIP_LEFT_RIGHT) if i%2 else base; im=bright(scaled(im,.97+.06*rnd.random()),.85+.45*rnd.random())
            fr.append(im)
        anims[f'{name}_anim']=(fr,fps,True,name)
    flicker('fire',8,14,'fire'); flicker('flame',8,16,'fire'); flicker('poison',8,8,'pulse'); flicker('electric',6,18,'flick'); flicker('laser',6,20,'flick_noflip')
    cw=max(f.width for fr,_,_,_ in anims.values() for f in fr)+6; ch=max(f.height for fr,_,_,_ in anims.values() for f in fr)+6
    maxn=max(len(fr) for fr,_,_,_ in anims.values()); sheet=Image.new('RGBA',(cw*maxn,ch*len(anims)),(0,0,0,0)); frames={}
    for r,(an,(fr,fps,loop,src)) in enumerate(anims.items()):
        names=[]
        for i,f in enumerate(fr):
            x=i*cw; y=r*ch; sheet.alpha_composite(f,(x+(cw-f.width)//2,y+(ch-f.height)//2)); nm=f'{an}_{i:02d}'
            frames[nm]={'x':x,'y':y,'w':cw,'h':ch,'pivot':[.5,.5],'trim':{'x':(cw-f.width)//2,'y':(ch-f.height)//2,'w':f.width,'h':f.height}}; names.append(nm)
        atlas['animations'][an]={'sheet':'fx_anim','frames':names,'fps':fps,'loop':loop,'source':src}
    sheet.save(f'{OUT}/fx_anim.png',optimize=True); atlas['sheets']['fx_anim']={'image':'fx_anim.png','cell':[cw,ch],'size':list(sheet.size),'frames':frames,'note':'derived from the poster stills (scale/fade/flicker), not hand-drawn'}
    # ───── UI extras (opaque crops) ─────
    ui={}
    ui['logo']=poster.crop((4,6,386,276)).convert('RGBA'); ui['loot_room']=poster.crop((1114,792,1306,976)).convert('RGBA')
    for n,im in ui.items(): im.save(f'{IND}/ui_{n}.png')
    sheet,cell,pos=pack(list(ui.values()),2); sheet.save(f'{OUT}/ui.png',optimize=True)
    atlas['sheets']['ui']={'image':'ui.png','cell':list(cell),'size':list(sheet.size),'frames':{n:{'x':p[0],'y':p[1],'w':p[2],'h':p[3],'pivot':[.5,.5],'trim':{'x':p[4],'y':p[5],'w':p[6],'h':p[7]}} for n,p in zip(ui,pos)},'note':'opaque art, not cut out'}
    json.dump(atlas,open(f'{OUT}/atlas.json','w'),indent=1)
    print({k:(v['size'],len(v['frames'])) for k,v in atlas['sheets'].items()}); print('animations:',{k:len(v['frames']) for k,v in atlas['animations'].items()})
    return atlas,sprites
if __name__=='__main__': main()
