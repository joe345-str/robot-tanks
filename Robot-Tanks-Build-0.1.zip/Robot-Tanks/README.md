# ROBOT-TANKS — Build 0.1
**Mad Purple Hat Games** · Destruction • Upgrade • Survive • Repeat

A playable local browser prototype featuring five selectable tank classes, enemy hordes, shooting, enemy projectiles, destructible/secret walls, loot, hull repair, upgrades, combo scoring, boss waves, announcer callouts, and touch controls.

## Run it

### Simplest option
Open `index.html` in a modern desktop or mobile browser. No build step or dependencies are required.

### Local web server (recommended for testing)
From this folder, run:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080` on the same device. For Android/Termux, run the command in the folder and open that address in your browser.

## Controls
- **Move:** WASD or arrow keys; mobile D-pad
- **Aim:** mouse or touch the arena
- **Fire:** mouse click, Space, or FIRE button
- **Special:** E or SPECIAL button
- **Redeploy after defeat:** R or REDEPLOY

## Tank classes
- **Mechanioid:** heavy siege cannon and radial siege blast
- **Android:** fast adaptive burst fire and radial burst
- **Drone:** fast, fragile carpet-bomb specialist
- **Mammoth Terminator:** slow, heavily armored ground shaker
- **Cyborg:** regeneration special

## Assets
`assets/sprites/robot-tanks-art-direction.png` is the concept/reference sheet for the intended detailed cartoon art direction. It is a single reference sheet, **not** a set of individually sliced production sprites. The prototype currently renders its gameplay actors with canvas-drawn shapes; the next art pass should create and integrate separate transparent PNG sprites, animation frames, and effects from scratch or properly licensed assets.

`assets/music/` and `assets/sounds/` are reserved for future OGG/WAV tracks and effects. No music or voice recordings are included yet; announcer lines currently appear as on-screen text.

## Important status
This is **Build 0.1, local single-player only**. Online multiplayer, persistent accounts/saves, server-authoritative gameplay, storefront integration, and real-money purchases are **not implemented**. Do not advertise those features as live until they have been built and tested. For secure multiplayer and purchases, the next milestone is a server/backend with validated entitlements rather than trusting browser-side flags.
